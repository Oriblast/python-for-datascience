def count_in_list(lst, item):
    """Compte le nombre d'occurrences de item dans lst."""
    return lst.count(item)
